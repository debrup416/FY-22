function cus_open() {
    document.getElementById("id-sidebar").style.display = "block";
}

function cus_close() {
    document.getElementById("id-sidebar").style.display = "none";
}